package com.bridgelabz.Oops.AddressBook.model;

public class Address {
private String Streetname;
private String BuildingName;
private String RoomNo;
private String State;
private String city;
public String getStreetname() {
	return Streetname;
}
public void setStreetname(String streetname) {
	Streetname = streetname;
}
public String getBuildingName() {
	return BuildingName;
}
public void setBuildingName(String buildingName) {
	BuildingName = buildingName;
}
public String getRoomNo() {
	return RoomNo;
}
public void setRoomNo(String roomNo) {
	RoomNo = roomNo;
}
public String getState() {
	return State;
}
public void setState(String state) {
	State = state;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}


}
